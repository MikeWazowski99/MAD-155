package com.example.turn_phone

import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "Landscape or Portrait"

        var button1 = findViewById<Button>(R.id.button)
        var textView1 = findViewById<TextView>(R.id.textView)
        var editTxt = findViewById<EditText>(R.id.userInput1)

        button1.setOnClickListener {
            val userInput = editTxt.text.toString()
            textView1.text = userInput
            if (button1.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT) {
                Toast.makeText(this@MainActivity, "This is portrait mode", Toast.LENGTH_SHORT).show()
            }
            else {
                Toast.makeText(this@MainActivity, "This is landscape mode", Toast.LENGTH_SHORT).show()
            }
        }
    }
}